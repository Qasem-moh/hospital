const Welcome = () => {
  return (
    <>
      <h1 style={{textAlign:"center"}}>Welcome in our Hospital</h1>

      <img
        src="https://www.diariosalud.do/wp-content/uploads/2020/06/fachada-img.jpg"
        alt=""
        style={{
          width: "1200px",
          height: "800px",
          alignItems: "center",
          display: "flex",
          marginLeft: "250px",
        }}
      />
    </>
  );
};

export default Welcome;
